# ChaiQuick - GitHub upload bundle

This folder is ready to be pushed to your GitHub repo (https://github.com/fluffles281-source/Idk.git).
After you push to the `main` branch, GitHub Actions will run and produce a plugin ZIP artifact that you can download and install in Aliucord.

## What to do (exact commands)
1. On your machine, clone your empty repo or change into its directory:
   git clone https://github.com/fluffles281-source/Idk.git
   cd Idk

2. Copy *all files from this bundle* into the repo root (or extract this archive into the repo root).
   If you downloaded the ZIP and are in the repo:
     unzip /path/to/ChaiQuick_GithubUpload.zip -d .
   Or copy files manually.

3. Commit & push:
   git add .
   git commit -m "Add ChaiQuick plugin source + CI"
   git push origin main

4. Open GitHub → YourRepo → Actions → Build ChaiQuick (the workflow will start). Wait for it to finish.

5. When the Action succeeds, go to the workflow run and download the artifact named `chaiquick-plugin-zip`.

## Notes
- The CI installs the Android command-line tools and build-tools and attempts to run `./gradlew assembleRelease`.
- The Actions job will create `classes.jar` from the build outputs and package it together with `manifest.json` into `ChaiQuick-plugin.zip`.
- If the build fails in CI due to missing Aliucord/Discord dependency jars, you will need to supply those jars in `libs/` or point the Gradle to a repo that hosts them. See the Troubleshooting section below.

## Troubleshooting
- **Gson manifest error**: make sure `authors` is an array of objects like: [{ "name": "You" }]
- **NullPointer / ClassNotFound**: Means the built zip did not include compiled classes.jar. Open the Action logs, ensure `assembleRelease` produced an `classes.jar` or `.aar`. The workflow attempts to extract the output and package it.
- If the Gradle build cannot find Discord/Aliucord classes, you may need to add the required dependencies to the `libs/` folder or use a custom Maven repository that hosts them.

If you want, I can also prepare a small helper script you can run locally that packages the plugin from the Gradle outputs into the final zip.

#!/bin/bash
# Local helper: run after a successful ./gradlew assembleRelease
# This script will try to collect classes.jar and package it with manifest.json
set -e
mkdir -p out final
AAR=$(find . -type f -name "*.aar" | head -n 1 || true)
if [ -n "$AAR" ]; then
  echo "Found AAR: $AAR"
  unzip -o "$AAR" -d tmp_a
  if [ -f tmp_a/classes.jar ]; then
    cp tmp_a/classes.jar out/classes.jar
  fi
fi
if [ ! -f out/classes.jar ]; then
  JAR=$(find . -type f -name "*-release.jar" | head -n 1 || true)
  if [ -n "$JAR" ]; then
    cp "$JAR" out/classes.jar
  fi
fi
if [ ! -f out/classes.jar ]; then
  echo "Could not find classes.jar or release jar. Check your build outputs."
  exit 1
fi
cp manifest.json final/
cp out/classes.jar final/classes.jar
cd final
zip -r ChaiQuick-plugin.zip .
echo "Package created: final/ChaiQuick-plugin.zip"

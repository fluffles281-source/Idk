package com.aliucord.plugins.chaiquick

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.appcompat.widget.AppCompatImageButton
import com.aliucord.Logger
import com.aliucord.Plugin
import com.aliucord.patcher.Hook
import com.discord.widgets.chat.input.WidgetChatInput

class ChaiQuick : Plugin() {
    private val log = Logger("ChaiQuick")

    override fun start(ctx: Context) {

        val method = WidgetChatInput::class.java.declaredMethods
            .firstOrNull { it.parameterTypes.size == 1 && it.parameterTypes[0] == View::class.java }

        if (method == null) {
            log.error("Could not find method to patch")
            return
        }

        patcher.patch(method, Hook { call ->
            val root = call.args[0] as? View ?: return@Hook
            val parent = root.parent as? ViewGroup ?: return@Hook

            if (parent.findViewWithTag<View>("chaiQuickFloat") != null) return@Hook

            val btn = AppCompatImageButton(root.context).apply {
                tag = "chaiQuickFloat"
                setImageResource(android.R.drawable.ic_dialog_email)
                background = null
                alpha = 0.85f
                val size = (root.resources.displayMetrics.density * 42).toInt()
                layoutParams = FrameLayout.LayoutParams(size, size, Gravity.END or Gravity.BOTTOM).apply {
                    val margin = (root.resources.displayMetrics.density * 64).toInt()
                    setMargins(0, 0, margin, margin)
                }

                setOnClickListener {
                    val url = "https://chai.ai/chat"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        putExtra("com.discord.BROWSER", true)
                    }
                    context.startActivity(intent)
                }
            }

            val frame = parent as? FrameLayout
                ?: FrameLayout(root.context).also { frameLayout ->
                    parent.removeView(root)
                    frameLayout.addView(root, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
                    parent.addView(frameLayout)
                }

            frame.addView(btn)
        })
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }
}
